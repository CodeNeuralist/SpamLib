# Spam Classifier Library

![GitHub](https://img.shields.io/github/license/yourusername/yourproject)
![GitHub release (latest by date)](https://img.shields.io/github/v/release/yourusername/yourproject)

A library for spam classification using neural networks in Python.

## Installation

You can install the library via pip:

```bash
pip install TotoSpam
